package server.shareholders_app_backend.config;

public final class ApplicationConstants {
    private ApplicationConstants() {

    }

    public static final int TOTAL_SHARES_IN_COMPANY = 4070921;
}
