package server.shareholders_app_backend.exception;

public class ShareholderDeletionException extends RuntimeException {
    public ShareholderDeletionException(String message) {
        super(message);
    }
}
